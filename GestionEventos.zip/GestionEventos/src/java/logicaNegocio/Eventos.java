/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaNegocio;

import java.io.Serializable;
import Persistencia.Persistencia;
import java.io.File;

/**
 *
 * @author carlo
 */
public class Eventos implements Serializable{
    private String identificación, nombres, fecha, hora, lugar, descripcion;

    public Eventos(String identificación, String nombres, String fecha, String hora, String lugar, String descripcion) {
        this.identificación = identificación;
        this.nombres = nombres;
        this.fecha = fecha;
        this.hora = hora;
        this.lugar = lugar;
        this.descripcion = descripcion;
    }

    public Eventos() {
    }

    public String getIdentificación() {
        return identificación;
    }

    public void setIdentificación(String identificación) {
        this.identificación = identificación;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public void grabarEvento(){
        Persistencia.conectarArchivo(new File("eventos.dat"), "grabar");
        Persistencia.grabarObjeto(this);
    }
    
    public void consultarEvento(){
        
    }
}
